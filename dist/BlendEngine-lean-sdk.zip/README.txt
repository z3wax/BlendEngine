BlendEngine lean native-game SDK
===============================

Unpack this archive to a workspace. Copy scripts/addons_core/blendengine/ into
Blender 3.6's scripts/addons/ directory and enable the addon. The separate addon
profile ZIP supports installation through Blender Preferences.
If the addon is installed outside this SDK, set the BLENDENGINE_SOURCE_ROOT
environment variable to this extracted SDK directory before launching Blender.

native/android_game/ contains the native Godot Android project. Godot, Blender,
JDK, Android SDK, export templates and signing keys are external prerequisites.
tools/blendengine/export_native_assets.py exports source scene assets into the
native project. See docs/LEAN_ENGINE.md and native/android_game/ documentation.

No prebuilt editor, APK, engine binary, SDK cache, or signing key is included.
Test a native APK on Android before uploading changes or artifacts to GitHub.
The source checkout's copyright and third-party license notices are preserved.
See MANIFEST.json for every shipped file's source path and SHA-256 checksum.

Source: https://github.com/z3wax/BlendEngine
