BlendEngine lean editor addon
============================

Install this ZIP from Blender 3.6 Preferences > Add-ons > Install, then enable
BlendEngine. The blendengine/ folder can also be placed in scripts/addons/.
Blender itself is required and is not included. No C++ executable or APK is
built by this package. Use the addon to create scenes and export a separate
native game; the native Android export requires the lean SDK's native project,
Godot and its Android toolchain. Create the SDK with the packager's --profile sdk.
For an installed addon, set BLENDENGINE_SOURCE_ROOT to the extracted SDK root
before starting Blender so the native project and asset-export tool can be found.

All game/editor modules, the portable Last Signal character, and brand assets
are included. Generated games, browser/WebView builds, downloaded model caches,
Python bytecode, backups, and the upstream C++ source tree are omitted.
Existing materials, textures, geometry and graphics settings are not modified.

COPYING, doc/license/, release/license/, release/text/copyright.txt and the
SPDX headers preserve the source's license and attribution notices. See
MANIFEST.json for the exact source paths, sizes and SHA-256 checksums.

Source: https://github.com/z3wax/BlendEngine
